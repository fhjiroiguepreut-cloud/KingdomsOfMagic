extends Node
## Autoload "GameInput": une teclado, ratón y controles táctiles en una sola API.

signal toggle_camera_pressed

const MOUSE_SENS := 0.0025

var touch_move := Vector2.ZERO
var _look := Vector2.ZERO
var _jump_requested := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_add_key("move_forward", KEY_W)
	_add_key("move_forward", KEY_UP)
	_add_key("move_back", KEY_S)
	_add_key("move_back", KEY_DOWN)
	_add_key("move_left", KEY_A)
	_add_key("move_left", KEY_LEFT)
	_add_key("move_right", KEY_D)
	_add_key("move_right", KEY_RIGHT)
	_add_key("jump", KEY_SPACE)
	_add_key("sprint", KEY_SHIFT)
	_add_key("toggle_camera", KEY_V)


func _add_key(action: StringName, keycode: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)


func get_move_vector() -> Vector2:
	var kb := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	return (kb + touch_move).limit_length(1.0)


func add_look(delta: Vector2) -> void:
	_look += delta


func consume_look() -> Vector2:
	var d := _look
	_look = Vector2.ZERO
	return d


func request_jump() -> void:
	_jump_requested = true


func consume_jump() -> bool:
	var j := _jump_requested
	_jump_requested = false
	return j


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_look += event.relative * MOUSE_SENS
	elif event is InputEventMouseButton and event.pressed and OS.has_feature("pc"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event.is_action_pressed("toggle_camera"):
		toggle_camera_pressed.emit()
