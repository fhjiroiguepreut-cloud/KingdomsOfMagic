extends Node3D
## Cámara en primera/tercera persona con brazo elástico anticolisión.

signal mode_changed(first_person: bool)

const THIRD_PERSON_DISTANCE := 4.5
const EYE_HEIGHT := 1.6

var yaw := 0.0
var pitch := -0.2
var first_person := false

var _target: Node3D
var _pitch_node: Node3D
var _arm: SpringArm3D
var _camera: Camera3D


func setup(target: Node3D) -> void:
	_target = target
	top_level = true
	_pitch_node = Node3D.new()
	add_child(_pitch_node)
	_arm = SpringArm3D.new()
	_arm.spring_length = THIRD_PERSON_DISTANCE
	_arm.margin = 0.25
	_arm.collision_mask = 1
	if target is CollisionObject3D:
		_arm.add_excluded_object((target as CollisionObject3D).get_rid())
	_pitch_node.add_child(_arm)
	_camera = Camera3D.new()
	_camera.fov = 75.0
	_camera.far = 400.0
	_arm.add_child(_camera)
	_camera.make_current()
	global_position = target.global_position + Vector3(0, EYE_HEIGHT, 0)


func toggle() -> void:
	first_person = not first_person
	mode_changed.emit(first_person)


func _process(delta: float) -> void:
	if _target == null:
		return
	var look := GameInput.consume_look()
	yaw -= look.x
	pitch = clampf(pitch - look.y, -1.3, 1.2)
	rotation.y = yaw
	_pitch_node.rotation.x = pitch
	global_position = _target.global_position + Vector3(0, EYE_HEIGHT, 0)
	var wanted := 0.0 if first_person else THIRD_PERSON_DISTANCE
	_arm.spring_length = lerpf(_arm.spring_length, wanted, clampf(12.0 * delta, 0.0, 1.0))
