# Kingdoms of Magic

RPG 3D de fantasía medieval y magia ambientado en **Eldoria**. Motor: **Godot 4.3** (GDScript). Plataforma principal: **Android**.

## Estado

| Fase | Contenido | Estado |
|------|-----------|--------|
| 1 | Proyecto, personaje 3D provisional, movimiento, cámara 1ª/3ª persona, terreno | Escrita, **pendiente de probar en Godot** |
| 2 | Controles táctiles y HUD | Solo joystick, cámara táctil y 2 botones (base) |
| 3-10 | Magia, combate, enemigos, misiones, inventario, Aetheria, jefe, guardado/optimización | Pendientes |

El APK aún no se ha generado ni probado: el entorno donde se escribió el código no tiene Godot instalado.

## Ejecutar en PC

1. Instala [Godot 4.3](https://godotengine.org/download) (versión estándar, no .NET).
2. Abre `project.godot` desde el Project Manager y pulsa **F5**.
3. Controles: WASD mover, Shift correr, Espacio saltar, V cambiar cámara, ratón para mirar (clic captura el ratón, Esc lo libera).
4. Para probar los controles táctiles en PC: ejecuta con `godot -- --touch`.

## Generar el APK

1. Instala JDK 17 y Android SDK (build-tools 34, platform-tools, cmdline-tools, platform android-34, CMake y NDK según pida Godot).
2. En Godot: **Editor > Administrar plantillas de exportación** e instala las de 4.3.
3. **Editor > Ajustes del editor > Exportar > Android**: indica rutas del Android SDK y del JDK.
4. **Proyecto > Exportar > Android** (el preset ya está en `export_presets.cfg`) y elige un keystore de depuración o el tuyo.
5. Exporta como APK e instálalo con `adb install build/KingdomsOfMagic.apk`.

Nunca subas keystores ni contraseñas: `.gitignore` los excluye. Para firmar versiones de lanzamiento usa secretos de GitHub.

## GitHub Actions

`.github/workflows/android.yml` exporta un APK de depuración en cada push usando `barichello/godot-ci:4.3` y un keystore temporal. Está sin probar: puede necesitar ajustes de rutas del SDK.

## Estructura

Ver `docs/ARQUITECTURA.md`.

## Licencia

MIT (código). Todos los recursos actuales son primitivas generadas por código; los futuros recursos deberán ser originales o de licencia redistribuible.
