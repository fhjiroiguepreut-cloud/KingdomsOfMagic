extends CharacterBody3D
## Jugador (Fase 1): movimiento, salto, modelo provisional con primitivas 3D y cámara.

const CameraRigScript := preload("res://scripts/player/camera_rig.gd")

const WALK_SPEED := 5.0
const SPRINT_SPEED := 8.0
const JUMP_VELOCITY := 6.0
const ACCELERATION := 40.0

var rig: Node3D
var model: Node3D
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)


func _ready() -> void:
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	col.shape = cap
	col.position.y = 0.9
	add_child(col)

	model = Node3D.new()
	add_child(model)

	var robe := CapsuleMesh.new()
	robe.radius = 0.4
	robe.height = 1.5
	_add_mesh(robe, Vector3(0, 0.8, 0), Color(0.25, 0.3, 0.8))

	var head := SphereMesh.new()
	head.radius = 0.22
	head.height = 0.44
	_add_mesh(head, Vector3(0, 1.62, 0), Color(0.9, 0.75, 0.6))

	var staff := CylinderMesh.new()
	staff.top_radius = 0.03
	staff.bottom_radius = 0.04
	staff.height = 1.7
	_add_mesh(staff, Vector3(0.45, 0.85, -0.2), Color(0.4, 0.25, 0.1))

	var orb := SphereMesh.new()
	orb.radius = 0.09
	orb.height = 0.18
	_add_mesh(orb, Vector3(0.45, 1.75, -0.2), Color(0.6, 0.4, 1.0))

	# "Nariz": marca el frente del personaje (-Z).
	_add_mesh(BoxMesh.new(), Vector3(0, 1.62, -0.2), Color(0.9, 0.75, 0.6), Vector3(0.08, 0.08, 0.16))

	rig = CameraRigScript.new()
	add_child(rig)
	rig.setup(self)
	rig.mode_changed.connect(func(fp: bool) -> void: model.visible = not fp)
	GameInput.toggle_camera_pressed.connect(rig.toggle)


func _add_mesh(mesh: Mesh, pos: Vector3, color: Color, mesh_scale := Vector3.ONE) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.9
	mi.material_override = mat
	mi.position = pos
	mi.scale = mesh_scale
	model.add_child(mi)


func _physics_process(delta: float) -> void:
	var input := GameInput.get_move_vector()
	var dir := Basis(Vector3.UP, rig.yaw) * Vector3(input.x, 0.0, input.y)
	var speed := SPRINT_SPEED if Input.is_action_pressed("sprint") else WALK_SPEED
	var target := dir * speed
	velocity.x = move_toward(velocity.x, target.x, ACCELERATION * delta)
	velocity.z = move_toward(velocity.z, target.z, ACCELERATION * delta)

	if is_on_floor():
		if Input.is_action_just_pressed("jump") or GameInput.consume_jump():
			velocity.y = JUMP_VELOCITY
	else:
		velocity.y -= _gravity * delta
	move_and_slide()

	if dir.length() > 0.1:
		var wanted := atan2(-dir.x, -dir.z)
		model.rotation.y = lerp_angle(model.rotation.y, wanted, clampf(12.0 * delta, 0.0, 1.0))
	elif rig.first_person:
		model.rotation.y = rig.yaw
