extends StaticBody3D
## Terreno procedural de bajo coste (malla low-poly con colisión) para la zona inicial de Aetheria.

const CELLS := 128
const CELL_SIZE := 2.0

var _noise := FastNoiseLite.new()


func _ready() -> void:
	_noise.seed = 7
	_noise.frequency = 0.012
	_noise.fractal_octaves = 4
	_build()


## Altura del terreno en coordenadas de mundo. Plana en el centro (futura Academia Arcana).
func get_height_at(x: float, z: float) -> float:
	var h := _noise.get_noise_2d(x, z) * 14.0
	var flat := smoothstep(12.0, 40.0, Vector2(x, z).length())
	var edge := smoothstep(80.0, 120.0, maxf(absf(x), absf(z))) * 25.0
	return lerpf(1.0, h, flat) + edge


func _color_for(h: float, x: float, z: float) -> Color:
	var v := _noise.get_noise_2d(x * 3.1, z * 3.1) * 0.06
	if h > 18.0:
		return Color(0.46 + v, 0.46 + v, 0.5 + v)
	if h > 10.0:
		return Color(0.38 + v, 0.4 + v, 0.25 + v)
	return Color(0.22 + v, 0.5 + v, 0.2 + v)


func _vertex(st: SurfaceTool, ix: int, iz: int) -> void:
	var half := CELLS * CELL_SIZE * 0.5
	var x := ix * CELL_SIZE - half
	var z := iz * CELL_SIZE - half
	var h := get_height_at(x, z)
	st.set_color(_color_for(h, x, z))
	st.add_vertex(Vector3(x, h, z))


func _build() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for iz in CELLS:
		for ix in CELLS:
			# a(ix,iz) b(ix+1,iz) c(ix,iz+1) d(ix+1,iz+1); sentido horario = cara frontal en Godot
			_vertex(st, ix, iz)
			_vertex(st, ix + 1, iz)
			_vertex(st, ix, iz + 1)
			_vertex(st, ix + 1, iz)
			_vertex(st, ix + 1, iz + 1)
			_vertex(st, ix, iz + 1)
	st.generate_normals()
	var mesh := st.commit()

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mesh.surface_set_material(0, mat)

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	add_child(mi)

	var cs := CollisionShape3D.new()
	cs.shape = mesh.create_trimesh_shape()
	add_child(cs)
