extends Node3D
## Escena principal de la Fase 1: construye entorno, luz, terreno, árboles, jugador y UI.

const PlayerScene := preload("res://scenes/player/player.tscn")
const TerrainScript := preload("res://scripts/world/terrain.gd")
const TouchControlsScript := preload("res://scripts/ui/touch_controls.gd")
const DebugHudScript := preload("res://scripts/ui/debug_hud.gd")

var terrain: StaticBody3D


func _ready() -> void:
	_setup_environment()
	terrain = TerrainScript.new()
	add_child(terrain)
	_scatter_trees()

	var player := PlayerScene.instantiate()
	player.position = Vector3(0, terrain.get_height_at(0, 0) + 1.5, 0)
	add_child(player)

	add_child(DebugHudScript.new())
	add_child(TouchControlsScript.new())


func _setup_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.8, 0.9)
	env.fog_density = 0.003
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 80.0
	add_child(sun)


func _scatter_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 1234

	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.15
	trunk.bottom_radius = 0.25
	trunk.height = 2.0
	var trunk_mat := StandardMaterial3D.new()
	trunk_mat.albedo_color = Color(0.35, 0.22, 0.1)
	trunk.material = trunk_mat

	var leaves := CylinderMesh.new()
	leaves.top_radius = 0.0
	leaves.bottom_radius = 1.3
	leaves.height = 3.2
	var leaves_mat := StandardMaterial3D.new()
	leaves_mat.albedo_color = Color(0.1, 0.38, 0.15)
	leaves.material = leaves_mat

	var positions: Array[Vector3] = []
	while positions.size() < 300:
		var x := rng.randf_range(-110.0, 110.0)
		var z := rng.randf_range(-110.0, 110.0)
		if Vector2(x, z).length() < 16.0:
			continue
		positions.append(Vector3(x, terrain.get_height_at(x, z), z))

	_add_multimesh(trunk, positions, 1.0)
	_add_multimesh(leaves, positions, 3.2)


func _add_multimesh(mesh: Mesh, positions: Array[Vector3], y_offset: float) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = positions.size()
	for i in positions.size():
		var s := 0.8 + float(i % 7) * 0.08
		var t := Transform3D(Basis().scaled(Vector3(s, s, s)), positions[i] + Vector3(0, y_offset * s, 0))
		mm.set_instance_transform(i, t)
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	add_child(mmi)
