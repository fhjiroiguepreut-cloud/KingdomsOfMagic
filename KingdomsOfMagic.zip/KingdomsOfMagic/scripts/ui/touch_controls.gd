extends CanvasLayer
## Controles táctiles: joystick virtual (zona izquierda), cámara por arrastre (zona derecha)
## y botones. Solo se activa en dispositivos táctiles o con el argumento de usuario "--touch".

const JOY_RADIUS := 110.0
const LOOK_SENS := 0.005

var _overlay: Control
var _move_idx := -1
var _look_idx := -1
var _origin := Vector2.ZERO
var _pos := Vector2.ZERO
var _buttons: Array[Button] = []


func _ready() -> void:
	layer = 10
	var enabled := DisplayServer.is_touchscreen_available() or OS.has_feature("mobile") \
		or OS.get_cmdline_user_args().has("--touch")
	if not enabled:
		set_process_input(false)
		return
	_overlay = Control.new()
	_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_overlay)
	_overlay.draw.connect(_draw_overlay)
	_make_button("Cámara", 1.0, 0.0, Rect2(-200, 20, 180, 80), func() -> void: GameInput.toggle_camera_pressed.emit())
	_make_button("Saltar", 1.0, 1.0, Rect2(-240, -240, 200, 100), func() -> void: GameInput.request_jump())


func _make_button(text: String, ax: float, ay: float, r: Rect2, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.anchor_left = ax
	b.anchor_right = ax
	b.anchor_top = ay
	b.anchor_bottom = ay
	b.offset_left = r.position.x
	b.offset_top = r.position.y
	b.offset_right = r.position.x + r.size.x
	b.offset_bottom = r.position.y + r.size.y
	b.pressed.connect(cb)
	_overlay.add_child(b)
	_buttons.append(b)


func _over_button(p: Vector2) -> bool:
	for b in _buttons:
		if b.get_global_rect().has_point(p):
			return true
	return false


func _input(event: InputEvent) -> void:
	var split_x := get_viewport().get_visible_rect().size.x * 0.45
	if event is InputEventScreenTouch:
		if event.pressed:
			if _over_button(event.position):
				return
			if event.position.x < split_x and _move_idx == -1:
				_move_idx = event.index
				_origin = event.position
				_pos = event.position
			elif event.position.x >= split_x and _look_idx == -1:
				_look_idx = event.index
		else:
			if event.index == _move_idx:
				_move_idx = -1
				GameInput.touch_move = Vector2.ZERO
			elif event.index == _look_idx:
				_look_idx = -1
		_overlay.queue_redraw()
	elif event is InputEventScreenDrag:
		if event.index == _move_idx:
			_pos = event.position
			GameInput.touch_move = ((_pos - _origin) / JOY_RADIUS).limit_length(1.0)
			_overlay.queue_redraw()
		elif event.index == _look_idx:
			GameInput.add_look(event.relative * LOOK_SENS)


func _draw_overlay() -> void:
	if _move_idx == -1:
		return
	_overlay.draw_circle(_origin, JOY_RADIUS, Color(1, 1, 1, 0.12))
	_overlay.draw_arc(_origin, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.4), 3.0)
	_overlay.draw_circle(_origin + (_pos - _origin).limit_length(JOY_RADIUS), 45.0, Color(1, 1, 1, 0.35))
