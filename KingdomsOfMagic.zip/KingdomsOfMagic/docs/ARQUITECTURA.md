# Arquitectura (Fase 1)

- `scripts/player/game_input.gd` (autoload `GameInput`): API única de entrada. Registra las acciones de teclado por código, recibe el vector del joystick táctil y el desplazamiento de cámara (ratón o toque).
- `scripts/player/player.gd`: `CharacterBody3D` con colisión de cápsula, modelo provisional hecho con primitivas, movimiento relativo a la cámara, correr y salto.
- `scripts/player/camera_rig.gd`: cámara con yaw/pitch, `SpringArm3D` (no atraviesa paredes) y cambio primera/tercera persona (tecla V o botón táctil).
- `scripts/world/terrain.gd`: malla low-poly procedural (FastNoiseLite) con colisión trimesh y colores por altura; zona central plana para la futura Academia Arcana.
- `scripts/main/main.gd`: monta entorno, sol con sombras, terreno, 300 árboles con `MultiMesh`, jugador y UI.
- `scripts/ui/touch_controls.gd`: joystick virtual, arrastre de cámara, botones Cámara y Saltar (solo en dispositivos táctiles o con `-- --touch`).

Las carpetas con `.gitkeep` están reservadas para las fases 3-10.
