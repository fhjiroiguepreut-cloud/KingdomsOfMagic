extends CanvasLayer
## HUD de depuración de la Fase 1 (FPS y ayuda de controles). Se sustituirá por el HUD real en la Fase 2.

var _label := Label.new()


func _ready() -> void:
	layer = 5
	_label.position = Vector2(16, 12)
	_label.add_theme_font_size_override("font_size", 20)
	add_child(_label)


func _process(_delta: float) -> void:
	_label.text = "Kingdoms of Magic - Fase 1\nFPS: %d\nWASD mover | Shift correr | Espacio saltar | V cámara | Esc liberar ratón" % Engine.get_frames_per_second()
